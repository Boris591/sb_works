<?php

return [
    '741rtsB',
    'fc14saa',
    '++rd*ssa',
    'vcspDSxxx',
    'N297qlk'
];