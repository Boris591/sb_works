<div class="clearfix">
        <?php \tempView\menu_render($arrMenu, '\tempView\matchDesc', 'main-menu bottom') ?>
</div>

<div class="footer">&copy;&nbsp;<nobr>2018</nobr> Project.</div>

</body>
</html>
