<?php

$arrMenu = [
    ['title' => 'Тест', 'path' => '/route/test/', 'sort' => 3],
    ['title' => 'О нас', 'path' => '/route/about/', 'sort' => 2],
    ['title' => 'Блог', 'path' => '/route/blog/', 'sort' => 4],
    ['title' => 'Новостиииииииииииииииииии', 'path' => '/route/news/', 'sort' => 1],
    ['title' => 'Главная', 'path' => '/', 'sort' => 0],

];
