<?php

define("UPLOAD_DIR", $_SERVER['DOCUMENT_ROOT'].'/upload/');
define("MAX_SIZE", 5000000);
define("FILE_TYPES", [
    'image/png',
    'image/jpeg',
    'image/jpg'
]);

